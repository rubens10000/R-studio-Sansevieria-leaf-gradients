#' @title plot_leaf_gradient
#'
#' @description Convenience wrapper for faceted leaf-gradient plots.
#'   All visual parameters are exposed so you can customize everything
#'   at call time without reinstalling the package.
#'
#' @param data         A data frame.
#' @param x_var        Column for x-axis / leaf zones. Default \code{"Leaf_position"}.
#' @param y_var        Column for response variable. Default \code{"suc"}.
#' @param facet_row    Column for facet rows. Default \code{"Time_point"}.
#' @param facet_col    Columns for facet columns. Default \code{c("Species","Condition")}.
#' @param species      \code{"trifasciata"} or \code{"cylindrica"}.
#' @param low_col      Color for low concentration. Default \code{"white"}.
#' @param high_col     Color for high concentration. Default \code{"#1a7a1a"}.
#' @param fix_scale    Logical. Fix color scale across facets. Default \code{TRUE}.
#' @param unified      Logical. Single-leaf-with-zones mode. Default \code{FALSE}.
#'
#' @section Leaf shape parameters (unified mode):
#' @param height       Numeric. Leaf half-height in npc. Default \code{NULL} (auto).
#' @param taper_power  Numeric. How sharply the leaf tapers to the tip.
#'                     Higher values = sharper tip. Default \code{NULL}
#'                     (auto: 2.5 for trifasciata, 4 for cylindrica).
#'                     Try values between 1.5 and 6.
#' @param base_spread  Numeric. How quickly the leaf widens from the base.
#'                     Lower = wider sooner. Default \code{NULL}
#'                     (auto: 0.45 trifasciata, 0.3 cylindrica).
#'                     Try values between 0.2 and 0.8.
#'
#' @section Boxplot styling:
#' @param show_boxplot     Logical. Default \code{TRUE}.
#' @param show_beeswarm    Logical. Default \code{TRUE}.
#' @param show_median_value Logical. Show median value label. Default \code{TRUE}.
#' @param box_lwd          Numeric. Box outline thickness. Default 0.3.
#' @param median_lwd       Numeric. Median line thickness. Default 0.6.
#' @param whisker_lwd      Numeric. Whisker line thickness. Default 0.25.
#' @param box_fill_alpha   Numeric (0-1). Box fill transparency. Default 0.55.
#' @param box_col          Color for box outline & whiskers. Default \code{"#2d5a1b"}.
#' @param median_col       Color for median line & label. Default \code{"#1a3a0a"}.
#'
#' @section Point styling:
#' @param point_size   Numeric (cex). Default 0.35.
#' @param point_alpha  Numeric (0-1). Default 0.55.
#' @param point_col    Color. Default \code{"#1a3a0a"}.
#'
#' @section Leaf outline styling:
#' @param outline_lwd  Numeric. Leaf outline thickness. Default 0.5.
#' @param outline_col  Color for leaf outline. Default \code{NULL} (auto green).
#' @param leaf_alpha   Numeric (0-1). Leaf fill transparency. Default \code{NULL}.
#'
#' @section Zone styling:
#' @param zone_gap         Numeric. Gap between zones in npc. Default 0.004.
#' @param zone_label_size  Numeric. Zone label font size (pt). Default 9.
#' @param zone_divider_lwd Numeric. Divider line width. Default 0.7.
#' @param zone_divider_col Color for dividers. Default \code{"#2d5a1b"}.
#' @param median_label_size Numeric. Median value label size (pt). Default 7.
#'
#' @section Grid & axis controls (unified mode):
#' @param show_grid_y  Logical. Show horizontal grid lines. Default \code{FALSE}.
#' @param show_axis_y  Logical. Show y-axis text & ticks. Default \code{FALSE}.
#' @param show_axis_x  Logical. Show x-axis text & ticks. Default \code{FALSE}.
#' @param show_panel_border Logical. Show panel border. Default \code{TRUE}.
#'
#' @section Labels:
#' @param x_label      x-axis label. Default \code{"Leaf Position  (Base -> Tip)"}.
#' @param y_label      y-axis label. Default \code{"Concentration"}.
#' @param caption      Character or \code{NULL}. Custom caption. Default \code{NULL} (auto).
#'                     Set to \code{""} to suppress caption entirely.
#' @param cld_data     Optional CLD letters data frame.
#' @param row_labels   Named character vector for row facet labels.
#' @param base_size    Numeric. Base font size for theme. Default 12.
#'
#' @return A \code{ggplot} object.
#' @export
plot_leaf_gradient <- function(
    data,
    x_var        = "Leaf_position",
    y_var        = "suc",
    facet_row    = "Time_point",
    facet_col    = c("Species", "Condition"),
    species      = "trifasciata",
    low_col      = "white",
    high_col     = "#1a7a1a",
    fix_scale    = TRUE,
    unified      = FALSE,
    # ── leaf shape ──
    height       = NULL,
    taper_power  = NULL,
    base_spread  = NULL,
    # ── boxplot ──
    show_boxplot      = TRUE,
    show_beeswarm     = TRUE,
    show_median_value = TRUE,
    box_lwd       = 0.3,
    median_lwd    = 0.6,
    whisker_lwd   = 0.25,
    box_fill_alpha = 0.55,
    box_col       = "#2d5a1b",
    median_col    = "#1a3a0a",
    # ── points ──
    point_size    = 0.35,
    point_alpha   = 0.55,
    point_col     = "#1a3a0a",
    # ── outline ──
    outline_lwd   = 0.5,
    outline_col   = NULL,
    leaf_alpha    = NULL,
    # ── zones ──
    zone_gap          = 0.004,
    zone_label_size   = 9,
    zone_divider_lwd  = 0.7,
    zone_divider_col  = "#2d5a1b",
    median_label_size = 7,
    # ── grid & axes ──
    show_grid_y       = FALSE,
    show_axis_y       = FALSE,
    show_axis_x       = FALSE,
    show_panel_border = TRUE,
    # ── labels & theme ──
    x_label      = "Leaf Position  (Base -> Tip)",
    y_label      = "Concentration",
    caption      = NULL,
    cld_data     = NULL,
    row_labels   = NULL,
    base_size    = 12
) {

  df <- data
  df$.x  <- df[[x_var]]
  df$.y  <- df[[y_var]]
  df$.fr <- df[[facet_row]]
  for (fc in facet_col) df[[fc]] <- df[[fc]]

  gmin <- if (fix_scale) min(df$.y, na.rm = TRUE) else NULL
  gmax <- if (fix_scale) max(df$.y, na.rm = TRUE) else NULL

  # ── Choose geom ────────────────────────────────────────────
  if (unified) {
    p <- ggplot2::ggplot(df, ggplot2::aes(x = .x, y = .y)) +
      geom_leaf_unified(
        species           = species,
        low_col           = low_col,
        high_col          = high_col,
        global_min        = gmin,
        global_max        = gmax,
        height            = height,
        taper_power       = taper_power,
        base_spread       = base_spread,
        show_boxplot      = show_boxplot,
        show_beeswarm     = show_beeswarm,
        show_median_value = show_median_value,
        box_lwd           = box_lwd,
        median_lwd        = median_lwd,
        whisker_lwd       = whisker_lwd,
        box_fill_alpha    = box_fill_alpha,
        box_col           = box_col,
        median_col        = median_col,
        point_size        = point_size,
        point_alpha       = point_alpha,
        point_col         = point_col,
        outline_lwd       = outline_lwd,
        outline_col       = outline_col,
        leaf_alpha        = leaf_alpha,
        zone_gap          = zone_gap,
        zone_label_size   = zone_label_size,
        zone_divider_lwd  = zone_divider_lwd,
        zone_divider_col  = zone_divider_col,
        median_label_size = median_label_size
      )
  } else {
    p <- ggplot2::ggplot(df, ggplot2::aes(x = .x, y = .y)) +
      geom_leaf(
        species       = species,
        low_col       = low_col,
        high_col      = high_col,
        global_min    = gmin,
        global_max    = gmax,
        show_boxplot  = show_boxplot,
        show_beeswarm = show_beeswarm
      )
  }

  # ── CLD letters ────────────────────────────────────────────
  if (!is.null(cld_data)) {
    cld_data$.x  <- cld_data[[x_var]]
    cld_data$.fr <- cld_data[[facet_row]]

    max_y_df <- df %>%
      dplyr::group_by(dplyr::across(dplyr::all_of(c(x_var, facet_row, facet_col)))) %>%
      dplyr::summarise(.max_y = max(.y, na.rm = TRUE), .groups = "drop")

    cld_data <- dplyr::left_join(cld_data, max_y_df,
                                  by = c(x_var, facet_row, facet_col))

    p <- p + ggplot2::geom_text(
      data = cld_data,
      ggplot2::aes(x = .x, y = .max_y, label = letters),
      vjust = -1.8, size = 4, fontface = "bold",
      inherit.aes = FALSE
    )
  }

  # ── Facets ─────────────────────────────────────────────────
  facet_col_formula <- paste(facet_col, collapse = " + ")
  facet_formula     <- stats::as.formula(paste(".fr ~", facet_col_formula))

  p <- p + ggplot2::facet_grid(
    facet_formula,
    labeller = if (!is.null(row_labels))
      ggplot2::labeller(.rows = row_labels)
    else
      ggplot2::label_value,
    switch = "y"
  )

  p <- p + ggplot2::scale_fill_identity()

  # ── Caption ────────────────────────────────────────────────
  if (is.null(caption)) {
    caption_text <- if (unified) {
      paste(
        "Horizontal leaf: zones colored by median concentration (white = low, green = high).",
        "Internal box: IQR +/- 1.5xIQR whiskers, median line + value.",
        "Points: individual observations (jittered). Zones: Base (left) -> Tip (right).",
        sep = "\n"
      )
    } else {
      paste(
        "Leaf color encodes median concentration (white = low, green = high).",
        "Internal box: IQR +/- 1.5xIQR whiskers, median line.",
        "Points: individual observations (jittered).",
        sep = "\n"
      )
    }
  } else {
    caption_text <- caption
  }

  # ── Labels ─────────────────────────────────────────────────
  p <- p + ggplot2::labs(
    x       = if (unified && !show_axis_x) NULL else x_label,
    y       = if (unified && !show_axis_y) NULL else y_label,
    caption = if (nchar(caption_text) > 0) caption_text else NULL
  )

  # ── Theme ──────────────────────────────────────────────────
  p <- p +
    ggplot2::theme_bw(base_size = base_size) +
    ggplot2::theme(
      panel.grid.minor   = ggplot2::element_blank(),
      panel.grid.major.x = ggplot2::element_blank(),
      strip.background   = ggplot2::element_rect(fill = NA),
      strip.text         = ggplot2::element_text(face = "bold"),
      plot.caption       = ggplot2::element_text(hjust = 0.5, face = "italic", size = 8),
      legend.position    = "right"
    ) +
    ggplot2::scale_y_continuous(
      expand = ggplot2::expansion(mult = c(0.02, 0.22))
    ) +
    ggplot2::coord_cartesian(clip = "off")

  # ── Unified-mode axis/grid overrides ───────────────────────
  if (unified) {
    axis_overrides <- list()

    if (!show_axis_x) {
      axis_overrides$axis.text.x  <- ggplot2::element_blank()
      axis_overrides$axis.ticks.x <- ggplot2::element_blank()
    }
    if (!show_axis_y) {
      axis_overrides$axis.text.y  <- ggplot2::element_blank()
      axis_overrides$axis.ticks.y <- ggplot2::element_blank()
    }
    if (!show_grid_y) {
      axis_overrides$panel.grid.major.y <- ggplot2::element_blank()
    }
    if (!show_panel_border) {
      axis_overrides$panel.border <- ggplot2::element_blank()
    }

    if (length(axis_overrides) > 0) {
      p <- p + do.call(ggplot2::theme, axis_overrides)
    }
  }

  p
}
