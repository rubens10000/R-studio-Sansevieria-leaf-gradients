#' @title GeomLeafSingle - ggproto for a single tri-zone leaf
#' @description Draws ONE leaf per panel, divided into 3 horizontal zones
#'   (Bottom, Middle, Top). Each zone is filled with a color encoding
#'   the median concentration of its group. Boxplots and beeswarm points
#'   are overlaid in each zone.
#' @keywords internal
GeomLeafSingle <- ggplot2::ggproto(
  "GeomLeafSingle", ggplot2::Geom,

  required_aes = c("x", "y"),

  default_aes = ggplot2::aes(
    colour    = "#2d5a1b",
    alpha     = 0.85,
    linewidth = 0.4,
    linetype  = 1
  ),

  draw_key = ggplot2::draw_key_polygon,

  # draw_panel gets ALL data in the panel (all x groups)
  draw_panel = function(data, panel_params, coord,
                        species        = "trifasciata",
                        low_col        = "white",
                        high_col       = "#1a7a1a",
                        width          = NULL,
                        show_boxplot   = TRUE,
                        show_beeswarm  = TRUE,
                        zone_gap       = 0.003,
                        ...) {

    if (nrow(data) == 0) return(grid::nullGrob())

    # ── identify the 3 zones from x groups ─────────────────────
    # x groups are expected to be factor levels: Bottom, Middle, Top
    # sorted by their numeric x value (1, 2, 3)
    groups <- split(data, data$x)
    x_vals <- sort(unique(data$x))
    n_zones <- length(x_vals)

    if (n_zones == 0) return(grid::nullGrob())

    # ── transform all data to npc ──────────────────────────────
    all_coords <- coord$transform(data, panel_params)

    # overall y range in npc space
    y_min_npc <- min(all_coords$y, na.rm = TRUE)
    y_max_npc <- max(all_coords$y, na.rm = TRUE)

    # center leaf at x midpoint
    x_center <- mean(range(all_coords$x, na.rm = TRUE))

    # Default width per species
    if (is.null(width)) {
      width <- if (species == "cylindrica") 0.06 else 0.14
    }

    # ── build full leaf outline ────────────────────────────────
    leaf_fn <- if (species == "cylindrica") {
      cylindrica_leaf_coords
    } else {
      trifasciata_leaf_coords
    }

    leaf_pts <- leaf_fn(
      x_center = x_center,
      y_bottom = y_min_npc,
      y_top    = y_max_npc,
      width    = width
    )

    # ── compute zone boundaries ────────────────────────────────
    # Divide the leaf into n_zones equal vertical bands
    zone_breaks <- seq(y_min_npc, y_max_npc, length.out = n_zones + 1)

    grob_list <- list()

    # ── draw each zone as a clipped polygon ────────────────────
    for (i in seq_along(x_vals)) {
      xv <- x_vals[i]
      zone_data <- data[data$x == xv, , drop = FALSE]
      zone_coords <- coord$transform(zone_data, panel_params)

      fill_col <- zone_data$fill[1]
      if (is.null(fill_col) || is.na(fill_col)) fill_col <- "white"

      y_lo <- zone_breaks[i]   + if (i > 1) zone_gap / 2 else 0
      y_hi <- zone_breaks[i+1] - if (i < n_zones) zone_gap / 2 else 0

      # Clip leaf polygon to this zone's y-band
      zone_poly <- clip_polygon_to_yband(leaf_pts, y_lo, y_hi)

      if (nrow(zone_poly) < 3) next

      zone_grob <- grid::polygonGrob(
        x    = zone_poly$x,
        y    = zone_poly$y,
        default.units = "npc",
        gp   = grid::gpar(
          fill  = fill_col,
          col   = NA,
          alpha = data$alpha[1] %||% 0.85
        )
      )
      grob_list <- c(grob_list, list(zone_grob))

      # ── boxplot per zone ───────────────────────────────────
      if (show_boxplot && nrow(zone_coords) >= 5) {
        q <- quantile(zone_coords$y, c(0.25, 0.5, 0.75), na.rm = TRUE)
        iqr <- q[3] - q[1]
        w_lower <- max(min(zone_coords$y), q[1] - 1.5 * iqr)
        w_upper <- min(max(zone_coords$y), q[3] + 1.5 * iqr)

        # Get leaf width at the median y for box sizing
        hw <- get_leaf_halfwidth_at_y(leaf_pts, q[2]) * 0.5

        box_grob <- grid::rectGrob(
          x      = x_center,
          y      = (q[1] + q[3]) / 2,
          width  = hw * 2,
          height = q[3] - q[1],
          default.units = "npc",
          gp = grid::gpar(
            fill = scales::alpha("white", 0.55),
            col  = "#2d5a1b",
            lwd  = 1.2 * ggplot2::.pt
          )
        )
        median_grob <- grid::segmentsGrob(
          x0 = x_center - hw, x1 = x_center + hw,
          y0 = q[2],          y1 = q[2],
          default.units = "npc",
          gp = grid::gpar(col = "#1a3a0a", lwd = 2 * ggplot2::.pt)
        )
        whisker_lo <- grid::segmentsGrob(
          x0 = x_center, x1 = x_center,
          y0 = w_lower,  y1 = q[1],
          default.units = "npc",
          gp = grid::gpar(col = "#2d5a1b", lwd = 1 * ggplot2::.pt, lty = 2)
        )
        whisker_hi <- grid::segmentsGrob(
          x0 = x_center, x1 = x_center,
          y0 = q[3],     y1 = w_upper,
          default.units = "npc",
          gp = grid::gpar(col = "#2d5a1b", lwd = 1 * ggplot2::.pt, lty = 2)
        )
        grob_list <- c(grob_list, list(whisker_lo, whisker_hi, box_grob, median_grob))
      }

      # ── beeswarm per zone ──────────────────────────────────
      if (show_beeswarm && nrow(zone_coords) > 0) {
        set.seed(42 + i)
        # Jitter within the leaf width at each point's y
        jit_max <- sapply(zone_coords$y, function(yy) {
          get_leaf_halfwidth_at_y(leaf_pts, yy) * 0.35
        })
        jit <- stats::runif(nrow(zone_coords), -jit_max, jit_max)
        pt_grob <- grid::pointsGrob(
          x   = x_center + jit,
          y   = zone_coords$y,
          pch = 19,
          default.units = "npc",
          gp  = grid::gpar(
            col = scales::alpha("#1a3a0a", 0.55),
            cex = 0.35
          )
        )
        grob_list <- c(grob_list, list(pt_grob))
      }
    }

    # ── draw overall leaf outline on top ─────────────────────
    outline_grob <- grid::polygonGrob(
      x    = leaf_pts$x,
      y    = leaf_pts$y,
      default.units = "npc",
      gp   = grid::gpar(
        fill = NA,
        col  = data$colour[1] %||% "#2d5a1b",
        alpha = 1,
        lwd  = (data$linewidth[1] %||% 0.4) * ggplot2::.pt
      )
    )
    grob_list <- c(grob_list, list(outline_grob))

    # ── draw thin separator lines between zones ──────────────
    for (i in 2:n_zones) {
      y_sep <- zone_breaks[i]
      # Get leaf width at this y level for the separator line
      hw <- get_leaf_halfwidth_at_y(leaf_pts, y_sep)
      sep_grob <- grid::segmentsGrob(
        x0 = x_center - hw, x1 = x_center + hw,
        y0 = y_sep,         y1 = y_sep,
        default.units = "npc",
        gp = grid::gpar(
          col = scales::alpha("#2d5a1b", 0.4),
          lwd = 0.8 * ggplot2::.pt,
          lty = 3
        )
      )
      grob_list <- c(grob_list, list(sep_grob))
    }

    grid::gTree(children = do.call(grid::gList, grob_list))
  }
)


#' @title StatLeafSingle - computes fill per group for single-leaf display
#' @keywords internal
StatLeafSingle <- ggplot2::ggproto(
  "StatLeafSingle", ggplot2::Stat,

  required_aes = c("x", "y"),

  compute_panel = function(data, scales,
                            low_col    = "white",
                            high_col   = "#1a7a1a",
                            global_min = NULL,
                            global_max = NULL) {

    gmin <- if (!is.null(global_min)) global_min else min(data$y, na.rm = TRUE)
    gmax <- if (!is.null(global_max)) global_max else max(data$y, na.rm = TRUE)

    data %>%
      dplyr::group_by(x) %>%
      dplyr::mutate(
        fill = conc_to_color(median(y, na.rm = TRUE),
                             min_v = gmin, max_v = gmax,
                             low = low_col, high = high_col)
      ) %>%
      dplyr::ungroup()
  }
)


#' @title geom_leaf_single — single leaf with tri-zone coloring
#'
#' @description A ggplot2 geom that draws a **single** Sansevieria leaf per
#'   panel. The leaf is divided into horizontal zones (one per x-group),
#'   and each zone is filled with a color encoding that group's **median**
#'   concentration (white = low, green = high). Optional boxplots and
#'   jittered points are overlaid within each zone.
#'
#' @inheritParams geom_leaf
#' @param zone_gap  Numeric. Small gap between zones in npc units. Default 0.003.
#'
#' @export
geom_leaf_single <- function(mapping  = NULL,
                              data     = NULL,
                              stat     = StatLeafSingle,
                              position = "identity",
                              species       = "trifasciata",
                              low_col       = "white",
                              high_col      = "#1a7a1a",
                              global_min    = NULL,
                              global_max    = NULL,
                              width         = NULL,
                              show_boxplot  = TRUE,
                              show_beeswarm = TRUE,
                              zone_gap      = 0.003,
                              na.rm    = FALSE,
                              show.legend = NA,
                              inherit.aes = TRUE,
                              ...) {

  ggplot2::layer(
    data        = data,
    mapping     = mapping,
    stat        = stat,
    geom        = GeomLeafSingle,
    position    = position,
    show.legend = show.legend,
    inherit.aes = inherit.aes,
    params      = list(
      species       = species,
      low_col       = low_col,
      high_col      = high_col,
      global_min    = global_min,
      global_max    = global_max,
      width         = width,
      show_boxplot  = show_boxplot,
      show_beeswarm = show_beeswarm,
      zone_gap      = zone_gap,
      na.rm         = na.rm,
      ...
    )
  )
}
