# =====================================================================
# GeomLeafUnified — single horizontal leaf with colored zones
# =====================================================================

#' @title GeomLeafUnified
#' @description Internal ggproto class. Draws ONE horizontal leaf per panel.
#' @keywords internal
GeomLeafUnified <- ggplot2::ggproto(
  "GeomLeafUnified", ggplot2::Geom,

  required_aes = c("x", "y"),

  default_aes = ggplot2::aes(
    fill      = "white",
    colour    = "#2d5a1b",
    alpha     = 0.85,
    linewidth = 0.4,
    linetype  = 1
  ),

  draw_key = ggplot2::draw_key_polygon,

  draw_panel = function(data, panel_params, coord,
                        species       = "trifasciata",
                        low_col       = "white",
                        high_col      = "#1a7a1a",
                        height        = NULL,
                        # ── leaf shape ──
                        taper_power   = NULL,
                        base_spread   = NULL,
                        # ── boxplot styling ──
                        show_boxplot      = TRUE,
                        show_beeswarm     = TRUE,
                        show_median_value = TRUE,
                        box_lwd       = 0.3,
                        median_lwd    = 0.6,
                        whisker_lwd   = 0.25,
                        box_fill_alpha = 0.55,
                        box_col       = "#2d5a1b",
                        median_col    = "#1a3a0a",
                        # ── point styling ──
                        point_size    = 0.35,
                        point_alpha   = 0.55,
                        point_col     = "#1a3a0a",
                        # ── outline styling ──
                        outline_lwd   = 0.5,
                        outline_col   = NULL,
                        leaf_alpha    = NULL,
                        # ── zone styling ──
                        zone_gap      = 0.004,
                        zone_label_size    = 9,
                        zone_divider_lwd   = 0.7,
                        zone_divider_col   = "#2d5a1b",
                        median_label_size  = 7,
                        ...) {

    coords <- coord$transform(data, panel_params)

    groups  <- sort(unique(coords$x))
    n_zones <- length(groups)
    if (n_zones < 1) return(grid::nullGrob())

    # ── Defaults per species ────────────────────────────────────
    if (is.null(height))      height      <- if (species == "cylindrica") 0.18 else 0.35
    if (is.null(taper_power)) taper_power <- if (species == "cylindrica") 4    else 2.5
    if (is.null(base_spread)) base_spread <- if (species == "cylindrica") 0.3  else 0.45
    if (is.null(outline_col)) outline_col <- data$colour[1] %||% "#2d5a1b"
    if (is.null(leaf_alpha))  leaf_alpha  <- data$alpha[1]  %||% 0.85

    # ── Horizontal leaf layout ──────────────────────────────────
    x_left   <- 0.06
    x_right  <- 0.94
    y_center <- 0.50

    # ── Leaf half-height function ───────────────────────────────
    leaf_hh_at_t <- function(t) {
      t <- pmax(0, pmin(1, t))
      if (species == "cylindrica") {
        height * (1 - t^taper_power) * (0.85 + 0.15 * sin(pi * t^base_spread))
      } else {
        height * (1 - t^taper_power) * sin(pi * t^base_spread)
      }
    }

    leaf_hh_at_x <- function(xval) {
      t <- (xval - x_left) / (x_right - x_left)
      leaf_hh_at_t(t)
    }

    # ── Full leaf outline ───────────────────────────────────────
    n_outline <- 80
    t_seq <- seq(0, 1, length.out = n_outline)
    x_seq <- x_left + t_seq * (x_right - x_left)
    h_seq <- sapply(t_seq, leaf_hh_at_t)

    leaf_poly_x <- c(x_seq, rev(x_seq))
    leaf_poly_y <- c(y_center + h_seq, rev(y_center - h_seq))

    # ── Zone boundaries ─────────────────────────────────────────
    zone_breaks <- seq(x_left, x_right, length.out = n_zones + 1)
    grob_list   <- list()

    for (i in seq_len(n_zones)) {
      grp_x    <- groups[i]
      grp_data <- coords[coords$x == grp_x, , drop = FALSE]
      fill_col <- grp_data$fill[1]
      if (is.null(fill_col) || is.na(fill_col)) fill_col <- "white"

      zx_left  <- zone_breaks[i]   + if (i > 1)       zone_gap / 2 else 0
      zx_right <- zone_breaks[i+1] - if (i < n_zones) zone_gap / 2 else 0

      # ── Zone polygon ──
      n_pts  <- 30
      zx_seq <- seq(zx_left, zx_right, length.out = n_pts)
      zh_seq <- sapply(zx_seq, leaf_hh_at_x)

      zone_grob <- grid::polygonGrob(
        x = c(zx_seq, rev(zx_seq)),
        y = c(y_center + zh_seq, rev(y_center - zh_seq)),
        default.units = "npc",
        gp = grid::gpar(fill = fill_col, col = NA, alpha = leaf_alpha)
      )
      grob_list <- c(grob_list, list(zone_grob))

      # ── Zone divider ──
      if (i < n_zones) {
        div_x  <- zone_breaks[i + 1]
        div_hh <- leaf_hh_at_x(div_x)
        div_grob <- grid::segmentsGrob(
          x0 = div_x, x1 = div_x,
          y0 = y_center - div_hh, y1 = y_center + div_hh,
          default.units = "npc",
          gp = grid::gpar(col = zone_divider_col,
                           lwd = zone_divider_lwd * ggplot2::.pt, lty = 3)
        )
        grob_list <- c(grob_list, list(div_grob))
      }

      # ── Map data into zone's vertical space ──
      zone_x_mid <- (zx_left + zx_right) / 2
      zone_hh    <- leaf_hh_at_x(zone_x_mid)
      zone_y_bot <- y_center - zone_hh * 0.85
      zone_y_top <- y_center + zone_hh * 0.85
      zone_y_h   <- zone_y_top - zone_y_bot

      if (nrow(grp_data) > 0) {
        orig_y     <- grp_data$y
        data_range <- range(coords$y, na.rm = TRUE)
        if (diff(data_range) > 0) {
          mapped_y <- zone_y_bot + (orig_y - data_range[1]) /
            diff(data_range) * zone_y_h
        } else {
          mapped_y <- rep(y_center, length(orig_y))
        }

        raw_y <- data[data$x == data$x[coords$x == grp_x][1], "y", drop = TRUE]

        # ── Boxplot ──
        if (show_boxplot && length(mapped_y) >= 5) {
          q   <- quantile(mapped_y, c(0.25, 0.5, 0.75), na.rm = TRUE)
          iqr <- q[3] - q[1]
          w_lower <- max(min(mapped_y), q[1] - 1.5 * iqr)
          w_upper <- min(max(mapped_y), q[3] + 1.5 * iqr)
          box_hw  <- (zx_right - zx_left) * 0.28

          box_grob <- grid::rectGrob(
            x = zone_x_mid, y = (q[1] + q[3]) / 2,
            width = box_hw * 2, height = q[3] - q[1],
            default.units = "npc",
            gp = grid::gpar(fill = scales::alpha("white", box_fill_alpha),
                             col = box_col, lwd = box_lwd * ggplot2::.pt)
          )
          med_grob <- grid::segmentsGrob(
            x0 = zone_x_mid - box_hw, x1 = zone_x_mid + box_hw,
            y0 = q[2], y1 = q[2], default.units = "npc",
            gp = grid::gpar(col = median_col, lwd = median_lwd * ggplot2::.pt)
          )
          wh_lo <- grid::segmentsGrob(
            x0 = zone_x_mid, x1 = zone_x_mid,
            y0 = w_lower, y1 = q[1], default.units = "npc",
            gp = grid::gpar(col = box_col, lwd = whisker_lwd * ggplot2::.pt, lty = 2)
          )
          wh_hi <- grid::segmentsGrob(
            x0 = zone_x_mid, x1 = zone_x_mid,
            y0 = q[3], y1 = w_upper, default.units = "npc",
            gp = grid::gpar(col = box_col, lwd = whisker_lwd * ggplot2::.pt, lty = 2)
          )
          grob_list <- c(grob_list, list(wh_lo, wh_hi, box_grob, med_grob))

          # ── Median value label ──
          if (show_median_value) {
            med_val <- median(raw_y, na.rm = TRUE)
            med_label <- grid::textGrob(
              label = format(round(med_val, 1), nsmall = 1),
              x = zone_x_mid, y = q[2] - 0.025,
              default.units = "npc", hjust = 0.5, vjust = 1,
              gp = grid::gpar(col = median_col,
                               fontsize = median_label_size, fontface = "bold")
            )
            grob_list <- c(grob_list, list(med_label))
          }
        }

        # ── Beeswarm points ──
        if (show_beeswarm && length(mapped_y) > 0) {
          set.seed(42 + i)
          jit_hw <- (zx_right - zx_left) * 0.22
          jit    <- stats::runif(length(mapped_y), -jit_hw, jit_hw)
          pt_grob <- grid::pointsGrob(
            x = zone_x_mid + jit, y = mapped_y, pch = 19,
            default.units = "npc",
            gp = grid::gpar(col = scales::alpha(point_col, point_alpha),
                             cex = point_size)
          )
          grob_list <- c(grob_list, list(pt_grob))
        }

        # ── Zone label ──
        lbl <- tryCatch({
          if (!is.null(data$x_fct)) {
            lvls <- levels(data$x_fct)
            if (length(lvls) >= i) lvls[i] else as.character(i)
          } else {
            as.character(i)
          }
        }, error = function(e) as.character(i))

        label_hh <- leaf_hh_at_x(zone_x_mid)
        label_grob <- grid::textGrob(
          label = lbl,
          x = zone_x_mid, y = y_center - label_hh - 0.025,
          default.units = "npc", hjust = 0.5, vjust = 1,
          gp = grid::gpar(col = outline_col, fontsize = zone_label_size,
                           fontface = "bold.italic")
        )
        grob_list <- c(grob_list, list(label_grob))
      }
    }

    # ── Leaf outline on top ─────────────────────────────────────
    outline_grob <- grid::polygonGrob(
      x = leaf_poly_x, y = leaf_poly_y, default.units = "npc",
      gp = grid::gpar(fill = NA, col = outline_col, alpha = 1,
                       lwd = outline_lwd * ggplot2::.pt)
    )
    grob_list <- c(grob_list, list(outline_grob))

    grid::gTree(children = do.call(grid::gList, grob_list))
  }
)


# =====================================================================
# StatLeafUnified
# =====================================================================

#' @title StatLeafUnified
#' @keywords internal
StatLeafUnified <- ggplot2::ggproto(
  "StatLeafUnified", ggplot2::Stat,
  required_aes = c("x", "y"),
  compute_panel = function(data, scales,
                            low_col = "white", high_col = "#1a7a1a",
                            global_min = NULL, global_max = NULL) {
    gmin <- if (!is.null(global_min)) global_min else min(data$y, na.rm = TRUE)
    gmax <- if (!is.null(global_max)) global_max else max(data$y, na.rm = TRUE)
    if (is.factor(data$x)) { data$x_fct <- data$x } else { data$x_fct <- factor(data$x) }
    data %>%
      dplyr::group_by(x) %>%
      dplyr::mutate(
        fill = conc_to_color(median(y, na.rm = TRUE),
                             min_v = gmin, max_v = gmax,
                             low = low_col, high = high_col)
      ) %>%
      dplyr::ungroup()
  }
)


# =====================================================================
# geom_leaf_unified() — user-facing layer function
# =====================================================================

#' @title geom_leaf_unified — single horizontal leaf with colored zones
#'
#' @description A ggplot2 geom that draws a SINGLE Sansevieria leaf per panel.
#'
#' @param species          Character. \code{"trifasciata"} or \code{"cylindrica"}.
#' @param low_col          Color for minimum concentration. Default \code{"white"}.
#' @param high_col         Color for maximum concentration. Default \code{"#1a7a1a"}.
#' @param global_min       Numeric. Fix color scale minimum. Default \code{NULL}.
#' @param global_max       Numeric. Fix color scale maximum. Default \code{NULL}.
#' @param height           Numeric. Leaf half-height in npc. Default \code{NULL} (auto).
#' @param taper_power      Numeric. How sharply leaf tapers to tip.
#'                         Higher = sharper. Default \code{NULL} (auto: 2.5 trifasciata, 4 cylindrica).
#' @param base_spread      Numeric. How quickly leaf widens from base.
#'                         Lower = wider sooner. Default \code{NULL} (auto: 0.45 trifasciata, 0.3 cylindrica).
#' @param show_boxplot     Logical. Default \code{TRUE}.
#' @param show_beeswarm    Logical. Default \code{TRUE}.
#' @param show_median_value Logical. Show numeric median. Default \code{TRUE}.
#' @param box_lwd          Numeric. Boxplot outline thickness. Default 0.3.
#' @param median_lwd       Numeric. Median line thickness. Default 0.6.
#' @param whisker_lwd      Numeric. Whisker line thickness. Default 0.25.
#' @param box_fill_alpha   Numeric. Box fill transparency (0-1). Default 0.55.
#' @param box_col          Color for box outline/whiskers. Default \code{"#2d5a1b"}.
#' @param median_col       Color for median line/label. Default \code{"#1a3a0a"}.
#' @param point_size       Numeric. Beeswarm point size (cex). Default 0.35.
#' @param point_alpha      Numeric. Point transparency. Default 0.55.
#' @param point_col        Color for points. Default \code{"#1a3a0a"}.
#' @param outline_lwd      Numeric. Leaf outline thickness. Default 0.5.
#' @param outline_col      Color for leaf outline. Default \code{NULL} (uses colour aes).
#' @param leaf_alpha       Numeric. Leaf fill transparency. Default \code{NULL} (uses alpha aes).
#' @param zone_gap         Numeric. Gap between zones in npc. Default 0.004.
#' @param zone_label_size  Numeric. Zone label font size in pt. Default 9.
#' @param zone_divider_lwd Numeric. Zone divider line width. Default 0.7.
#' @param zone_divider_col Color for zone dividers. Default \code{"#2d5a1b"}.
#' @param median_label_size Numeric. Median value label font size. Default 7.
#' @param na.rm            Logical. Default \code{FALSE}.
#' @param ...              Additional arguments.
#'
#' @export
geom_leaf_unified <- function(mapping  = NULL,
                               data     = NULL,
                               stat     = StatLeafUnified,
                               position = "identity",
                               species       = "trifasciata",
                               low_col       = "white",
                               high_col      = "#1a7a1a",
                               global_min    = NULL,
                               global_max    = NULL,
                               height        = NULL,
                               taper_power   = NULL,
                               base_spread   = NULL,
                               show_boxplot      = TRUE,
                               show_beeswarm     = TRUE,
                               show_median_value = TRUE,
                               box_lwd       = 0.3,
                               median_lwd    = 0.6,
                               whisker_lwd   = 0.25,
                               box_fill_alpha = 0.55,
                               box_col       = "#2d5a1b",
                               median_col    = "#1a3a0a",
                               point_size    = 0.35,
                               point_alpha   = 0.55,
                               point_col     = "#1a3a0a",
                               outline_lwd   = 0.5,
                               outline_col   = NULL,
                               leaf_alpha    = NULL,
                               zone_gap      = 0.004,
                               zone_label_size    = 9,
                               zone_divider_lwd   = 0.7,
                               zone_divider_col   = "#2d5a1b",
                               median_label_size  = 7,
                               na.rm    = FALSE,
                               show.legend = NA,
                               inherit.aes = TRUE,
                               ...) {

  ggplot2::layer(
    data        = data,
    mapping     = mapping,
    stat        = stat,
    geom        = GeomLeafUnified,
    position    = position,
    show.legend = show.legend,
    inherit.aes = inherit.aes,
    params      = list(
      species           = species,
      low_col           = low_col,
      high_col          = high_col,
      global_min        = global_min,
      global_max        = global_max,
      height            = height,
      taper_power       = taper_power,
      base_spread       = base_spread,
      show_boxplot      = show_boxplot,
      show_beeswarm     = show_beeswarm,
      show_median_value = show_median_value,
      box_lwd           = box_lwd,
      median_lwd        = median_lwd,
      whisker_lwd       = whisker_lwd,
      box_fill_alpha    = box_fill_alpha,
      box_col           = box_col,
      median_col        = median_col,
      point_size        = point_size,
      point_alpha       = point_alpha,
      point_col         = point_col,
      outline_lwd       = outline_lwd,
      outline_col       = outline_col,
      leaf_alpha        = leaf_alpha,
      zone_gap          = zone_gap,
      zone_label_size   = zone_label_size,
      zone_divider_lwd  = zone_divider_lwd,
      zone_divider_col  = zone_divider_col,
      median_label_size = median_label_size,
      na.rm             = na.rm,
      ...
    )
  )
}


# =====================================================================
# Original geom_leaf (backward compatible — one leaf per group)
# =====================================================================

#' @title GeomLeaf
#' @description Internal ggproto class. Draws one leaf per x-group.
#' @keywords internal
GeomLeaf <- ggplot2::ggproto(
  "GeomLeaf", ggplot2::Geom,
  required_aes = c("x", "y"),
  default_aes = ggplot2::aes(
    fill = "white", colour = "#2d5a1b",
    alpha = 0.85, linewidth = 0.4, linetype = 1
  ),
  draw_key = ggplot2::draw_key_polygon,
  draw_group = function(data, panel_params, coord,
                        species = "trifasciata", low_col = "white",
                        high_col = "#1a7a1a", width = NULL,
                        show_boxplot = TRUE, show_beeswarm = TRUE, ...) {
    coords   <- coord$transform(data, panel_params)
    fill_col <- data$fill[1]
    if (is.null(fill_col) || is.na(fill_col)) fill_col <- "white"
    x_center <- mean(coords$x, na.rm = TRUE)
    y_min    <- min(coords$y, na.rm = TRUE)
    y_max    <- max(coords$y, na.rm = TRUE)
    if (is.null(width)) width <- if (species == "cylindrica") 0.04 else 0.09
    leaf_fn <- if (species == "cylindrica") cylindrica_leaf_coords else trifasciata_leaf_coords
    leaf_pts <- leaf_fn(x_center = x_center, y_bottom = y_min, y_top = y_max, width = width)
    leaf_grob <- grid::polygonGrob(
      x = leaf_pts$x, y = leaf_pts$y, default.units = "npc",
      gp = grid::gpar(fill = fill_col, col = data$colour[1] %||% "#2d5a1b",
                       alpha = data$alpha[1] %||% 0.85,
                       lwd = (data$linewidth[1] %||% 0.4) * ggplot2::.pt))
    grob_list <- list(leaf_grob)
    if (show_boxplot && nrow(coords) >= 5) {
      q <- quantile(coords$y, c(0.25,0.5,0.75), na.rm = TRUE)
      iqr <- q[3]-q[1]; w_lo <- max(min(coords$y),q[1]-1.5*iqr); w_hi <- min(max(coords$y),q[3]+1.5*iqr)
      hw <- width*0.55
      grob_list <- c(grob_list, list(
        grid::segmentsGrob(x0=x_center,x1=x_center,y0=w_lo,y1=q[1],default.units="npc",
                           gp=grid::gpar(col="#2d5a1b",lwd=1*ggplot2::.pt,lty=2)),
        grid::segmentsGrob(x0=x_center,x1=x_center,y0=q[3],y1=w_hi,default.units="npc",
                           gp=grid::gpar(col="#2d5a1b",lwd=1*ggplot2::.pt,lty=2)),
        grid::rectGrob(x=x_center,y=(q[1]+q[3])/2,width=hw*2,height=q[3]-q[1],default.units="npc",
                       gp=grid::gpar(fill=scales::alpha("white",0.55),col="#2d5a1b",lwd=1.2*ggplot2::.pt)),
        grid::segmentsGrob(x0=x_center-hw,x1=x_center+hw,y0=q[2],y1=q[2],default.units="npc",
                           gp=grid::gpar(col="#1a3a0a",lwd=2*ggplot2::.pt))))
    }
    if (show_beeswarm && nrow(coords) > 0) {
      set.seed(42)
      jit <- stats::runif(nrow(coords), -width*0.35, width*0.35)
      grob_list <- c(grob_list, list(
        grid::pointsGrob(x=x_center+jit,y=coords$y,pch=19,default.units="npc",
                         gp=grid::gpar(col=scales::alpha("#1a3a0a",0.55),cex=0.35))))
    }
    grid::gTree(children = do.call(grid::gList, grob_list))
  }
)


#' @title StatLeaf
#' @keywords internal
StatLeaf <- ggplot2::ggproto(
  "StatLeaf", ggplot2::Stat,
  required_aes = c("x", "y"),
  compute_panel = function(data, scales, low_col = "white", high_col = "#1a7a1a",
                            global_min = NULL, global_max = NULL) {
    gmin <- if (!is.null(global_min)) global_min else min(data$y, na.rm = TRUE)
    gmax <- if (!is.null(global_max)) global_max else max(data$y, na.rm = TRUE)
    data %>% dplyr::group_by(x) %>%
      dplyr::mutate(fill = conc_to_color(median(y, na.rm = TRUE),
                                          min_v = gmin, max_v = gmax,
                                          low = low_col, high = high_col)) %>%
      dplyr::ungroup()
  }
)


#' @title geom_leaf — original, one leaf per x-group
#' @inheritParams geom_leaf_unified
#' @export
geom_leaf <- function(mapping = NULL, data = NULL, stat = StatLeaf,
                       position = "identity", species = "trifasciata",
                       low_col = "white", high_col = "#1a7a1a",
                       global_min = NULL, global_max = NULL, width = NULL,
                       show_boxplot = TRUE, show_beeswarm = TRUE,
                       na.rm = FALSE, show.legend = NA, inherit.aes = TRUE, ...) {
  ggplot2::layer(data = data, mapping = mapping, stat = stat, geom = GeomLeaf,
    position = position, show.legend = show.legend, inherit.aes = inherit.aes,
    params = list(species = species, low_col = low_col, high_col = high_col,
      global_min = global_min, global_max = global_max, width = width,
      show_boxplot = show_boxplot, show_beeswarm = show_beeswarm, na.rm = na.rm, ...))
}
