#' @title plot_leaf_single
#'
#' @description Convenience wrapper that creates a faceted plot with a
#'   **single leaf per panel**, divided into colored zones (one per leaf
#'   position: Bottom, Middle, Top). Each zone's fill encodes the median
#'   concentration of that group.
#'
#' @inheritParams plot_leaf_gradient
#' @param zone_gap Numeric gap between zones. Default 0.003.
#'
#' @return A \code{ggplot} object.
#'
#' @examples
#' \dontrun{
#' library(leafviz)
#' library(dplyr)
#'
#' df <- expand.grid(
#'   Leaf_position = factor(c("Bottom","Middle","Top"),
#'                          levels = c("Bottom","Middle","Top")),
#'   Species       = c("Sp1","Sp2"),
#'   Condition     = c("Control","Drought"),
#'   Time_point    = factor(c("9","3"), levels = c("9","3"))
#' ) %>%
#'   dplyr::slice(rep(1:dplyr::n(), each = 8)) %>%
#'   dplyr::mutate(suc = abs(rnorm(dplyr::n(), 6, 2)))
#'
#' plot_leaf_single(df, species = "trifasciata")
#' }
#'
#' @export
plot_leaf_single <- function(
    data,
    x_var        = "Leaf_position",
    y_var        = "suc",
    facet_row    = "Time_point",
    facet_col    = c("Species", "Condition"),
    species      = "trifasciata",
    low_col      = "white",
    high_col     = "#1a7a1a",
    fix_scale    = TRUE,
    show_boxplot  = TRUE,
    show_beeswarm = TRUE,
    zone_gap      = 0.003,
    x_label      = "Leaf Position  (Base -> Tip)",
    y_label      = "Concentration",
    cld_data     = NULL,
    row_labels   = NULL
) {

  # ── rename to standard internals ─────────────────────────────
  df <- data
  df$.x  <- df[[x_var]]
  df$.y  <- df[[y_var]]
  df$.fr <- df[[facet_row]]
  for (fc in facet_col) df[[fc]] <- df[[fc]]

  gmin <- if (fix_scale) min(df$.y, na.rm = TRUE) else NULL
  gmax <- if (fix_scale) max(df$.y, na.rm = TRUE) else NULL

  # ── base mapping ──────────────────────────────────────────────
  p <- ggplot2::ggplot(df, ggplot2::aes(x = .x, y = .y)) +

    geom_leaf_single(
      species       = species,
      low_col       = low_col,
      high_col      = high_col,
      global_min    = gmin,
      global_max    = gmax,
      show_boxplot  = show_boxplot,
      show_beeswarm = show_beeswarm,
      zone_gap      = zone_gap
    )

  # ── CLD letters ───────────────────────────────────────────────
  if (!is.null(cld_data)) {
    cld_data$.x  <- cld_data[[x_var]]
    cld_data$.fr <- cld_data[[facet_row]]

    max_y_df <- df %>%
      dplyr::group_by(dplyr::across(dplyr::all_of(c(x_var, facet_row, facet_col)))) %>%
      dplyr::summarise(.max_y = max(.y, na.rm = TRUE), .groups = "drop")

    cld_data <- dplyr::left_join(cld_data, max_y_df,
                                  by = c(x_var, facet_row, facet_col))

    p <- p + ggplot2::geom_text(
      data = cld_data,
      ggplot2::aes(x = .x, y = .max_y, label = letters),
      vjust = -1.8, size = 4, fontface = "bold",
      inherit.aes = FALSE
    )
  }

  # ── facets ────────────────────────────────────────────────────
  facet_col_formula <- paste(facet_col, collapse = " + ")
  facet_formula     <- stats::as.formula(
    paste(".fr ~", facet_col_formula)
  )

  labeller_args <- list()
  if (!is.null(row_labels)) {
    labeller_args[[".fr"]] <- row_labels
  }

  p <- p + ggplot2::facet_grid(
    facet_formula,
    labeller = if (length(labeller_args) > 0)
      ggplot2::labeller(.rows = row_labels)
    else
      ggplot2::label_value,
    switch = "y"
  )

  p <- p + ggplot2::scale_fill_identity()

  # ── labels & theme ────────────────────────────────────────────
  p <- p +
    ggplot2::labs(
      x = x_label,
      y = y_label,
      caption = paste(
        "Single leaf per panel; zones colored by median concentration",
        "(white = low, green = high).",
        "Internal box: IQR +/- 1.5xIQR whiskers, median line.",
        "Points: individual observations (jittered).",
        sep = "\n"
      )
    ) +
    ggplot2::theme_bw(base_size = 12) +
    ggplot2::theme(
      panel.grid.minor   = ggplot2::element_blank(),
      panel.grid.major.x = ggplot2::element_blank(),
      strip.background   = ggplot2::element_rect(fill = NA),
      strip.text         = ggplot2::element_text(face = "bold"),
      plot.caption       = ggplot2::element_text(
        hjust = 0.5, face = "italic", size = 8
      ),
      legend.position    = "right"
    ) +
    ggplot2::scale_y_continuous(
      expand = ggplot2::expansion(mult = c(0.02, 0.22))
    ) +
    ggplot2::coord_cartesian(clip = "off")

  p
}
