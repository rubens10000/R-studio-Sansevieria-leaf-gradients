#' leafviz: Leaf-shaped concentration visualizations for Sansevieria
#'
#' @description
#' Provides ggplot2-compatible geoms for visualizing metabolite or ion
#' concentration gradients along leaves of *Sansevieria trifasciata* (snake
#' plant) or *Sansevieria cylindrica*. Concentration is encoded via a
#' white->green color ramp on a leaf-shaped glyph, with an optional transparent
#' boxplot overlay and raw data points inside the leaf outline.
#'
#' ## Main functions
#' - [geom_leaf()] ? ggplot2 layer for leaf-shaped glyphs
#' - [plot_leaf_gradient()] ? convenience wrapper mirroring the faceted
#'   gradient workflow
#'
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom dplyr group_by mutate ungroup summarise across all_of left_join
#' @importFrom ggplot2 ggplot aes layer ggproto Geom Stat draw_key_polygon
#'   element_blank element_rect element_text expansion facet_grid guide_colorbar
#'   label_value labeller scale_fill_gradient scale_y_continuous coord_cartesian
#'   theme theme_bw labs geom_text .pt
#' @importFrom grid polygonGrob rectGrob segmentsGrob pointsGrob gpar gList gTree
#' @importFrom scales rescale colour_ramp alpha
#' @importFrom rlang `%||%`
#' @importFrom stats quantile runif as.formula median
## usethis namespace: end
NULL
