#' @title Leaf shape polygon coordinates (trifasciata)
#' @description Generate polygon coordinates for a trifasciata leaf.
#'   Shape is controlled by \code{taper_power} and \code{base_spread}.
#'
#' @param x_center     Numeric. Center x position.
#' @param y_bottom     Numeric. Bottom y of the leaf.
#' @param y_top        Numeric. Top y of the leaf.
#' @param width        Numeric. Maximum half-width of the leaf.
#' @param n_points     Integer. Number of points on each side.
#' @param taper_power  Numeric. Controls how sharply the leaf tapers to the tip.
#'                     Higher = sharper tip (default 2.5). Range ~1.5 to 5.
#' @param base_spread  Numeric. Controls how quickly the leaf widens from the base.
#'                     Lower = wider sooner (default 0.45). Range ~0.2 to 0.8.
#'
#' @return A data.frame with columns x and y.
#' @keywords internal
trifasciata_leaf_coords <- function(x_center, y_bottom, y_top,
                                    width = 0.35, n_points = 60,
                                    taper_power = 2.5,
                                    base_spread = 0.45) {
  t <- seq(0, 1, length.out = n_points)
  w <- width * (1 - t^taper_power) * sin(pi * t^base_spread)
  y_vals <- y_bottom + t * (y_top - y_bottom)
  x_left  <- x_center - w
  x_right <- x_center + w
  data.frame(
    x = c(x_left, rev(x_right)),
    y = c(y_vals,  rev(y_vals))
  )
}


#' @title Leaf shape polygon coordinates (cylindrica)
#' @description Generate polygon coordinates for a cylindrica leaf.
#'   Shape is controlled by \code{taper_power} and \code{base_spread}.
#'
#' @inheritParams trifasciata_leaf_coords
#' @keywords internal
cylindrica_leaf_coords <- function(x_center, y_bottom, y_top,
                                   width = 0.18, n_points = 60,
                                   taper_power = 4,
                                   base_spread = 0.3) {
  t <- seq(0, 1, length.out = n_points)
  w <- width * (1 - t^taper_power) * (0.85 + 0.15 * sin(pi * t^base_spread))
  y_vals <- y_bottom + t * (y_top - y_bottom)
  x_left  <- x_center - w
  x_right <- x_center + w
  data.frame(
    x = c(x_left, rev(x_right)),
    y = c(y_vals,  rev(y_vals))
  )
}


#' @title Compute fill color from concentration
#' @description Maps a numeric concentration value to a color.
#' @param value  Numeric concentration value.
#' @param min_v  Minimum of the scale.
#' @param max_v  Maximum of the scale.
#' @param low    Color for low concentration.
#' @param high   Color for high concentration.
#' @return A hex color string.
#' @keywords internal
conc_to_color <- function(value, min_v, max_v,
                           low = "white", high = "#1a7a1a") {
  p <- scales::rescale(value, from = c(min_v, max_v))
  scales::colour_ramp(c(low, high))(p)
}
