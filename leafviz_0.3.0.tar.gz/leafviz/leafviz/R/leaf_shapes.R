#' @title Leaf shape polygon coordinates
#' @description Internal function to generate polygon coordinates
#'   for a Sansevieria trifasciata leaf (flat, broad, lanceolate).
#'
#' @param x_center  Numeric. Center x position.
#' @param y_bottom  Numeric. Bottom y of the leaf.
#' @param y_top     Numeric. Top y of the leaf.
#' @param width     Numeric. Maximum half-width of the leaf.
#' @param n_points  Integer. Number of points on each side.
#'
#' @return A data.frame with columns x and y.
#' @keywords internal
trifasciata_leaf_coords <- function(x_center, y_bottom, y_top,
                                    width = 0.35, n_points = 60) {
  # Normalised t from 0 (base) to 1 (tip)
  t <- seq(0, 1, length.out = n_points)

  # Width profile: broad at base, tapering to a sharp tip
  # Uses a beta-like curve: wide in lower 2/3, narrowing sharply at tip
  w <- width * (1 - t^2.5) * sin(pi * t^0.45)

  y_vals <- y_bottom + t * (y_top - y_bottom)

  # Left side (base->tip), right side (tip->base)
  x_left  <- x_center - w
  x_right <- x_center + w

  data.frame(
    x = c(x_left, rev(x_right)),
    y = c(y_vals,  rev(y_vals))
  )
}


#' @title Leaf shape polygon coordinates for cylindrica
#' @description Internal function to generate polygon coordinates
#'   for a Sansevieria cylindrica leaf (tubular/cylindrical cross-section,
#'   rendered as a narrower, more uniform elliptical shape).
#'
#' @inheritParams trifasciata_leaf_coords
#' @keywords internal
cylindrica_leaf_coords <- function(x_center, y_bottom, y_top,
                                   width = 0.18, n_points = 60) {
  t <- seq(0, 1, length.out = n_points)

  # Cylindrical: nearly constant width, slight taper only near tip
  w <- width * (1 - t^4) * (0.85 + 0.15 * sin(pi * t^0.3))

  y_vals <- y_bottom + t * (y_top - y_bottom)

  x_left  <- x_center - w
  x_right <- x_center + w

  data.frame(
    x = c(x_left, rev(x_right)),
    y = c(y_vals,  rev(y_vals))
  )
}


#' @title Compute fill color from concentration
#' @description Maps a numeric concentration value to a color on a
#'   white->green gradient.
#' @param value  Numeric concentration value.
#' @param min_v  Minimum of the scale.
#' @param max_v  Maximum of the scale.
#' @param low    Color for low concentration (default: "white").
#' @param high   Color for high concentration (default: "#1a6b1a").
#' @return A hex color string.
#' @keywords internal
conc_to_color <- function(value, min_v, max_v,
                           low = "white", high = "#1a7a1a") {
  p <- scales::rescale(value, from = c(min_v, max_v))
  scales::colour_ramp(c(low, high))(p)
}
