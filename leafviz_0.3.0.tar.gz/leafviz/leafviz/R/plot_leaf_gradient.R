#' @title plot_leaf_gradient
#'
#' @description Convenience wrapper that reproduces a faceted leaf-gradient
#'   plot analogous to your existing \code{p_gradient} workflow, but replaces
#'   standard boxplots with leaf-shaped glyphs.
#'
#' @param data         A data frame containing at minimum the columns named by
#'                     \code{x_var}, \code{y_var}, and any \code{facet_*} vars.
#' @param x_var        Name of the column used for x-axis (leaf position).
#'                     Default \code{"Leaf_position"}.
#' @param y_var        Name of the column for the response variable (concentration).
#'                     Default \code{"suc"}.
#' @param facet_row    Column name for facet rows.  Default \code{"Time_point"}.
#' @param facet_col    Column names for facet columns (character vector).
#'                     Default \code{c("Species", "Condition")}.
#' @param species      \code{"trifasciata"} or \code{"cylindrica"}.
#'                     Default \code{"trifasciata"}.
#' @param low_col      Color for low concentration. Default \code{"white"}.
#' @param high_col     Color for high concentration. Default \code{"#1a7a1a"}.
#' @param fix_scale    Logical. If \code{TRUE}, the color scale is fixed across
#'                     all facets using the global min/max. Default \code{TRUE}.
#' @param show_boxplot  Logical. Overlay IQR box inside leaf. Default \code{TRUE}.
#' @param show_beeswarm Logical. Overlay raw points inside leaf. Default \code{TRUE}.
#' @param x_label      x-axis label. Default \code{"Leaf Position  (Base -> Tip)"}.
#' @param y_label      y-axis label. Default \code{"Sucrose (umol g-1 FW)"}.
#' @param cld_data     Optional data frame with Tukey CLD letters to annotate.
#'                     Must contain columns matching \code{x_var}, \code{facet_row},
#'                     \code{facet_col}, and a \code{letters} column.
#' @param row_labels   Named character vector for facet row labels
#'                     (e.g. \code{c(`9` = "9 AM", `3` = "3 PM")}).
#'
#' @return A \code{ggplot} object.
#'
#' @examples
#' \dontrun{
#' library(leafviz)
#' library(dplyr)
#'
#' df <- expand.grid(
#'   Leaf_position = c("Bottom","Middle","Top"),
#'   Species       = c("Sp1","Sp2"),
#'   Condition     = c("Control","Drought"),
#'   Time_point    = c("9","3")
#' ) %>%
#'   dplyr::slice(rep(1:dplyr::n(), each = 8)) %>%
#'   dplyr::mutate(suc = abs(rnorm(dplyr::n(), 6, 2)))
#'
#' plot_leaf_gradient(df, species = "trifasciata")
#' }
#'
#' @export
plot_leaf_gradient <- function(
    data,
    x_var        = "Leaf_position",
    y_var        = "suc",
    facet_row    = "Time_point",
    facet_col    = c("Species", "Condition"),
    species      = "trifasciata",
    low_col      = "white",
    high_col     = "#1a7a1a",
    fix_scale    = TRUE,
    show_boxplot  = TRUE,
    show_beeswarm = TRUE,
    x_label      = "Leaf Position  (Base -> Tip)",
    y_label      = "Concentration",
    cld_data     = NULL,
    row_labels   = NULL
) {

  # ?? rename to standard internals ?????????????????????????????
  df <- data
  df$.x  <- df[[x_var]]
  df$.y  <- df[[y_var]]
  df$.fr <- df[[facet_row]]
  for (fc in facet_col) df[[fc]] <- df[[fc]]  # keep as-is

  gmin <- if (fix_scale) min(df$.y, na.rm = TRUE) else NULL
  gmax <- if (fix_scale) max(df$.y, na.rm = TRUE) else NULL

  # ?? base mapping ??????????????????????????????????????????????
  p <- ggplot2::ggplot(df, ggplot2::aes(x = .x, y = .y)) +

    geom_leaf(
      species       = species,
      low_col       = low_col,
      high_col      = high_col,
      global_min    = gmin,
      global_max    = gmax,
      show_boxplot  = show_boxplot,
      show_beeswarm = show_beeswarm
    )

  # ?? CLD letters ???????????????????????????????????????????????
  if (!is.null(cld_data)) {
    cld_data$.x  <- cld_data[[x_var]]
    cld_data$.fr <- cld_data[[facet_row]]

    # max_y per group for letter position
    max_y_df <- df %>%
      dplyr::group_by(dplyr::across(dplyr::all_of(c(x_var, facet_row, facet_col)))) %>%
      dplyr::summarise(.max_y = max(.y, na.rm = TRUE), .groups = "drop")

    cld_data <- dplyr::left_join(cld_data, max_y_df,
                                  by = c(x_var, facet_row, facet_col))

    p <- p + ggplot2::geom_text(
      data = cld_data,
      ggplot2::aes(x = .x, y = .max_y, label = letters),
      vjust = -1.8, size = 4, fontface = "bold",
      inherit.aes = FALSE
    )
  }

  # ?? facets ????????????????????????????????????????????????????
  facet_col_formula <- paste(facet_col, collapse = " + ")
  facet_formula     <- stats::as.formula(
    paste(".fr ~", facet_col_formula)
  )

  labeller_args <- list()
  if (!is.null(row_labels)) {
    labeller_args[[".fr"]] <- row_labels
  }

  p <- p + ggplot2::facet_grid(
    facet_formula,
    labeller = if (length(labeller_args) > 0)
      ggplot2::labeller(.rows = row_labels)
    else
      ggplot2::label_value,
    switch = "y"
  )

  # Leaf fill colors are already hex strings computed by StatLeaf,
  # so we use scale_fill_identity and suppress the legend (leaf color
  # is self-explanatory from the caption).
  p <- p + ggplot2::scale_fill_identity()

  # ── labels & theme ─────────────────────────────────────────────
  p <- p +
    ggplot2::labs(
      x = x_label,
      y = y_label,
      caption = paste(
        "Leaf color encodes median concentration (white = low, green = high).",
        "Internal box: IQR +/- 1.5xIQR whiskers, median line.",
        "Points: individual observations (jittered).",
        sep = "\n"
      )
    ) +
    ggplot2::theme_bw(base_size = 12) +
    ggplot2::theme(
      panel.grid.minor  = ggplot2::element_blank(),
      panel.grid.major.x = ggplot2::element_blank(),
      strip.background  = ggplot2::element_rect(fill = NA),
      strip.text        = ggplot2::element_text(face = "bold"),
      plot.caption      = ggplot2::element_text(
        hjust = 0.5, face = "italic", size = 8
      ),
      legend.position   = "right"
    ) +
    ggplot2::scale_y_continuous(
      expand = ggplot2::expansion(mult = c(0.02, 0.22))
    ) +
    ggplot2::coord_cartesian(clip = "off")

  p
}
