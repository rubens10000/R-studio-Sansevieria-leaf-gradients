#' @title GeomLeaf - ggproto object for leaf geom
#' @description Internal ggproto class.
#' @keywords internal
GeomLeaf <- ggplot2::ggproto(
  "GeomLeaf", ggplot2::Geom,

  required_aes = c("x", "y"),

  default_aes = ggplot2::aes(
    fill        = "white",
    colour      = "#2d5a1b",
    alpha       = 0.85,
    linewidth   = 0.4,
    linetype    = 1
  ),

  draw_key = ggplot2::draw_key_polygon,

  # data here is one group (one leaf position x facet)
  draw_group = function(data, panel_params, coord,
                        species  = "trifasciata",
                        low_col  = "white",
                        high_col = "#1a7a1a",
                        width    = NULL,
                        show_boxplot = TRUE,
                        show_beeswarm = TRUE,
                        ...) {

    # ?? coordinate range ??????????????????????????????????????
    coords <- coord$transform(data, panel_params)

    # use the pre-computed fill from StatLeaf
    fill_col <- data$fill[1]
    if (is.null(fill_col) || is.na(fill_col)) fill_col <- "white"

    x_center <- mean(coords$x, na.rm = TRUE)
    y_min    <- min(coords$y,  na.rm = TRUE)
    y_max    <- max(coords$y,  na.rm = TRUE)

    # Default width per species
    if (is.null(width)) {
      width <- if (species == "cylindrica") 0.04 else 0.09
    }

    # ?? build leaf polygon ????????????????????????????????????
    leaf_fn <- if (species == "cylindrica") {
      cylindrica_leaf_coords
    } else {
      trifasciata_leaf_coords
    }

    leaf_pts <- leaf_fn(
      x_center = x_center,
      y_bottom = y_min,
      y_top    = y_max,
      width    = width
    )

    # scale back to npc via coord transform (already in [0,1] panel space)
    leaf_grob <- grid::polygonGrob(
      x    = leaf_pts$x,
      y    = leaf_pts$y,
      default.units = "npc",
      gp   = grid::gpar(
        fill     = fill_col,
        col      = data$colour[1] %||% "#2d5a1b",
        alpha    = data$alpha[1]  %||% 0.85,
        lwd      = (data$linewidth[1] %||% 0.4) * ggplot2::.pt
      )
    )

    # ?? optional boxplot whiskers ?????????????????????????????
    grob_list <- list(leaf_grob)

    if (show_boxplot && nrow(coords) >= 5) {
      q <- quantile(coords$y, c(0.25, 0.5, 0.75), na.rm = TRUE)
      iqr <- q[3] - q[1]
      w_lower <- max(min(coords$y), q[1] - 1.5 * iqr)
      w_upper <- min(max(coords$y), q[3] + 1.5 * iqr)

      hw <- width * 0.55  # half-box width

      box_grob <- grid::rectGrob(
        x      = x_center,
        y      = (q[1] + q[3]) / 2,
        width  = hw * 2,
        height = q[3] - q[1],
        default.units = "npc",
        gp = grid::gpar(
          fill = scales::alpha("white", 0.55),
          col  = "#2d5a1b",
          lwd  = 1.2 * ggplot2::.pt
        )
      )

      median_grob <- grid::segmentsGrob(
        x0 = x_center - hw, x1 = x_center + hw,
        y0 = q[2],          y1 = q[2],
        default.units = "npc",
        gp = grid::gpar(col = "#1a3a0a", lwd = 2 * ggplot2::.pt)
      )

      whisker_lo <- grid::segmentsGrob(
        x0 = x_center, x1 = x_center,
        y0 = w_lower,  y1 = q[1],
        default.units = "npc",
        gp = grid::gpar(col = "#2d5a1b", lwd = 1 * ggplot2::.pt, lty = 2)
      )
      whisker_hi <- grid::segmentsGrob(
        x0 = x_center, x1 = x_center,
        y0 = q[3],     y1 = w_upper,
        default.units = "npc",
        gp = grid::gpar(col = "#2d5a1b", lwd = 1 * ggplot2::.pt, lty = 2)
      )

      grob_list <- c(grob_list,
                     list(whisker_lo, whisker_hi, box_grob, median_grob))
    }

    # ?? beeswarm-style points ?????????????????????????????????
    if (show_beeswarm && nrow(coords) > 0) {
      # Simple jitter (true beeswarm needs ggbeeswarm, keep self-contained)
      set.seed(42)
      jit <- stats::runif(nrow(coords), -width * 0.35, width * 0.35)
      pt_grob <- grid::pointsGrob(
        x   = x_center + jit,
        y   = coords$y,
        pch = 19,
        default.units = "npc",
        gp  = grid::gpar(
          col  = scales::alpha("#1a3a0a", 0.55),
          cex  = 0.35
        )
      )
      grob_list <- c(grob_list, list(pt_grob))
    }

    grid::gTree(children = do.call(grid::gList, grob_list))
  }
)


#' @title StatLeaf - computes per-group fill color from median concentration
#' @keywords internal
StatLeaf <- ggplot2::ggproto(
  "StatLeaf", ggplot2::Stat,

  required_aes = c("x", "y"),

  compute_panel = function(data, scales,
                            low_col  = "white",
                            high_col = "#1a7a1a",
                            global_min = NULL,
                            global_max = NULL) {

    gmin <- if (!is.null(global_min)) global_min else min(data$y, na.rm = TRUE)
    gmax <- if (!is.null(global_max)) global_max else max(data$y, na.rm = TRUE)

    data %>%
      dplyr::group_by(x) %>%
      dplyr::mutate(
        fill = conc_to_color(median(y, na.rm = TRUE),
                             min_v = gmin, max_v = gmax,
                             low = low_col, high = high_col)
      ) %>%
      dplyr::ungroup()
  }
)


#' @title geom_leaf ? leaf-shaped concentration visualization
#'
#' @description A ggplot2 geom that draws a Sansevieria leaf shape for each
#'   group on the x-axis. The leaf is filled with a color gradient encoding
#'   the **median** concentration (white = low, green = high). An optional
#'   transparent boxplot and jittered raw points are overlaid inside the leaf.
#'
#' @param species      Character. `"trifasciata"` (flat, broad leaf, default)
#'                     or `"cylindrica"` (narrow, tubular leaf).
#' @param low_col      Color for the minimum concentration end of the scale.
#'                     Default `"white"`.
#' @param high_col     Color for the maximum concentration end of the scale.
#'                     Default `"#1a7a1a"` (dark green).
#' @param global_min   Numeric. If supplied, fix the color scale minimum across
#'                     all facets (useful for multi-panel plots). Default `NULL`
#'                     (per-panel scaling).
#' @param global_max   Numeric. If supplied, fix the color scale maximum.
#'                     Default `NULL`.
#' @param width        Numeric. Half-width of the leaf in panel-npc units.
#'                     Default `NULL` (auto: 0.09 for trifasciata, 0.04 for
#'                     cylindrica).
#' @param show_boxplot Logical. Draw a transparent IQR box + whiskers + median
#'                     line inside the leaf. Default `TRUE`.
#' @param show_beeswarm Logical. Draw jittered raw data points inside the leaf.
#'                     Default `TRUE`.
#' @param na.rm        Logical. Remove NAs silently. Default `FALSE`.
#' @param ...          Additional arguments passed to \code{layer()}.
#'
#' @section Aesthetics:
#' \code{geom_leaf()} understands the following aesthetics
#' (required in **bold**):
#' \itemize{
#'   \item \strong{x} ? leaf position (e.g. Bottom / Middle / Top)
#'   \item \strong{y} ? concentration value
#'   \item \code{colour} ? leaf outline color
#'   \item \code{alpha}  ? leaf transparency
#'   \item \code{linewidth} ? outline thickness
#' }
#'
#' @examples
#' \dontrun{
#' library(ggplot2)
#' library(leafviz)
#'
#' # Minimal example
#' df <- data.frame(
#'   position = rep(c("Bottom","Middle","Top"), each = 10),
#'   sucrose   = c(rnorm(10,5,1), rnorm(10,8,1.2), rnorm(10,3,0.8))
#' )
#' df$position <- factor(df$position, levels = c("Bottom","Middle","Top"))
#'
#' ggplot(df, aes(x = position, y = sucrose)) +
#'   geom_leaf(species = "trifasciata") +
#'   theme_bw()
#' }
#'
#' @export
geom_leaf <- function(mapping  = NULL,
                       data     = NULL,
                       stat     = StatLeaf,
                       position = "identity",
                       species       = "trifasciata",
                       low_col       = "white",
                       high_col      = "#1a7a1a",
                       global_min    = NULL,
                       global_max    = NULL,
                       width         = NULL,
                       show_boxplot  = TRUE,
                       show_beeswarm = TRUE,
                       na.rm    = FALSE,
                       show.legend = NA,
                       inherit.aes = TRUE,
                       ...) {

  ggplot2::layer(
    data        = data,
    mapping     = mapping,
    stat        = stat,
    geom        = GeomLeaf,
    position    = position,
    show.legend = show.legend,
    inherit.aes = inherit.aes,
    params      = list(
      species       = species,
      low_col       = low_col,
      high_col      = high_col,
      global_min    = global_min,
      global_max    = global_max,
      width         = width,
      show_boxplot  = show_boxplot,
      show_beeswarm = show_beeswarm,
      na.rm         = na.rm,
      ...
    )
  )
}
