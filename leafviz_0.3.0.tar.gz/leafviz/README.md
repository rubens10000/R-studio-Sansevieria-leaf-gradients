# leafviz

**Leaf-shaped concentration gradient plots for Sansevieria**

`leafviz` is a small ggplot2 extension that draws *Sansevieria trifasciata* or
*S. cylindrica* leaf silhouettes as plot glyphs.  Two display modes:

1. **Original** (`geom_leaf`): One vertical leaf per x-group (Bottom / Middle / Top),
   each colored by median concentration.
2. **Unified** (`geom_leaf_unified`): A **single horizontal leaf** per panel (base left,
   tip right), divided into vertical zones — one zone per x-group — each colored
   independently. Boxplots with median values and raw points overlaid within each zone.

---

## Installation

```r
install.packages("path/to/leafviz_0.2.0.tar.gz", repos = NULL, type = "source")
```

---

## Quick start — unified horizontal leaf (NEW in v0.2.0)

```r
library(leafviz)
library(ggplot2)
library(dplyr)

df <- expand.grid(
  Leaf_position = factor(c("Bottom","Middle","Top"),
                         levels = c("Bottom","Middle","Top")),
  Species       = c("Sansevieria_trifasciata", "Sansevieria_cylindrica"),
  Condition     = c("Control", "Drought"),
  Time_point    = factor(c("9","3"), levels = c("9","3"))
) %>%
  slice(rep(1:n(), each = 8)) %>%
  mutate(suc = abs(rnorm(n(), mean = 6, sd = 2.5)))

# ── Single horizontal leaf with 3 colored zones ──────────────
p <- plot_leaf_gradient(
  data       = df,
  y_label    = "Sucrose (µmol g⁻¹ FW)",
  species    = "trifasciata",
  row_labels = c(`9` = "9 AM", `3` = "3 PM"),
  fix_scale  = TRUE,
  unified    = TRUE           # ← one horizontal leaf per panel
)
print(p)
```

### Using geom_leaf_unified() directly

```r
ggplot(df %>% filter(Species == "Sansevieria_trifasciata",
                     Condition == "Control",
                     Time_point == "9"),
       aes(x = Leaf_position, y = suc)) +
  geom_leaf_unified(
    species           = "trifasciata",
    low_col           = "white",
    high_col          = "#1a7a1a",
    show_boxplot      = TRUE,
    show_beeswarm     = TRUE,
    show_median_value = TRUE     # ← shows median number on each box
  ) +
  theme_bw() +
  labs(y = "Sucrose (µmol g⁻¹ FW)")
```

---

## Parameters

### `geom_leaf_unified()` (NEW)

| Parameter | Default | Description |
|-----------|---------|-------------|
| `species` | `"trifasciata"` | Leaf shape: `"trifasciata"` (broad) or `"cylindrica"` (narrow) |
| `low_col` | `"white"` | Color for lowest concentration |
| `high_col` | `"#1a7a1a"` | Color for highest concentration |
| `global_min` | `NULL` | Fix color scale minimum |
| `global_max` | `NULL` | Fix color scale maximum |
| `height` | `NULL` | Leaf half-height in npc (auto: 0.35 trifasciata, 0.18 cylindrica) |
| `show_boxplot` | `TRUE` | Draw IQR box + whiskers + median inside each zone |
| `show_beeswarm` | `TRUE` | Draw jittered raw points inside each zone |
| `show_median_value` | `TRUE` | Display numeric median value below median line |

### `plot_leaf_gradient()`

All parameters above, plus:

| Parameter | Default | Description |
|-----------|---------|-------------|
| `unified` | `FALSE` | If `TRUE`, use horizontal single-leaf-with-zones mode |
| `x_var` | `"Leaf_position"` | Column for x-axis / zones |
| `y_var` | `"suc"` | Column for response |
| `facet_row` | `"Time_point"` | Column for facet rows |
| `facet_col` | `c("Species","Condition")` | Columns for facet columns |
| `fix_scale` | `TRUE` | Use global min/max for color scale |
| `cld_data` | `NULL` | Data frame with Tukey CLD letters |
| `row_labels` | `NULL` | Named vector for row facet labels |

---

## How the unified leaf works

1. **StatLeafUnified** computes median concentration per x-group and maps each
   to a fill color on a white→green ramp.
2. **GeomLeafUnified** draws a single **horizontal** leaf polygon (base left,
   tip right), divides it into vertical zones, fills each zone independently,
   and overlays per-zone boxplots (with median values) and jittered points.
3. Zone labels (e.g. "Bottom", "Middle", "Top") appear below the leaf.
4. Dashed divider lines mark zone boundaries within the leaf.
